package it.polimi.tiw.progettoTIW.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.progettoTIW.beans.Course;
import it.polimi.tiw.progettoTIW.beans.User;

public class CourseDAO {
	
	private Connection connection;
	
	public CourseDAO(Connection connection) {
		this.connection = connection;
	}
	
	public List<Course> findCoursesByTeacherId(int teacherId) throws SQLException {
		List<Course> courses = new ArrayList<Course>();
		String query = "SELECT * FROM course WHERE teacherid = ? ORDER BY name DESC";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, teacherId);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Course course = new Course();
					course.setId(result.getInt("id"));
					course.setName(result.getString("name"));
					course.setDescription(result.getString("description"));
					course.setHours(result.getInt("hours"));
					//course.setCfu(result.getInt("cfu"));
					course.setTeacherId(result.getInt("teacherid"));
					courses.add(course);
				}
			}
		}
		return courses;
	}
	
	public int findDefaultProjectForTeacher(int teacherId) throws SQLException {
		String query = "SELECT * FROM course WHERE teacherid = ? ORDER BY name DESC LIMIT 1";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, teacherId);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.isBeforeFirst()) {
					result.next();
					return result.getInt("id");
				}
			}
		}
		return -1;
	}
	
	public Course findCourseById(int courseId) throws SQLException {
		Course course = null;
		String query = "SELECT * FROM course WHERE id = ?";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, courseId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.isBeforeFirst()) {
					result.next();
					course = new Course();
					course.setId(result.getInt("id"));
					course.setName(result.getString("name"));
					course.setDescription(result.getString("description"));
					course.setHours(result.getInt("hours"));
					//course.setCfu(result.getInt("cfu"));
					course.setTeacherId(result.getInt("teacherid"));
				}
			}
		}
		return course;
	}
	
	public User findCourseOwner(int courseId) throws SQLException {
		User user = null;
		String query = "SELECT U.id, U.number, U.role FROM user U JOIN course C ON U.id = C.teacherid WHERE C.id = ?";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, courseId);
			try (ResultSet result = pstatement.executeQuery();) {
				if (result.isBeforeFirst()) {
					result.next();
					user = new User();
					user.setId(result.getInt("U.id"));
					user.setNumber(result.getString("U.number"));
					user.setRole(result.getString("U.role"));
				}
			}
		}
		return user;
	}

}
