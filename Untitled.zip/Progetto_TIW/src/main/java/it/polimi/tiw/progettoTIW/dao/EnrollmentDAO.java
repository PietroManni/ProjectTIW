package it.polimi.tiw.progettoTIW.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import it.polimi.tiw.progettoTIW.beans.Evaluation;
import it.polimi.tiw.progettoTIW.beans.Student;
import it.polimi.tiw.progettoTIW.beans.StudentEvaluation;

public class EnrollmentDAO {
	
	private Connection connection;
	
	public EnrollmentDAO(Connection connection) {
		this.connection = connection;
	}
	
	public List<StudentEvaluation> findEvaluationsByAppealId(int appealId) throws SQLException {
		List<StudentEvaluation> evaluations =  new ArrayList<StudentEvaluation>();
		String query = "SELECT * FROM student S JOIN enrollment E ON S.id = E.studentid WHERE E.idappeal = ?";
		try (PreparedStatement pstatement = connection.prepareStatement(query);) {
			pstatement.setInt(1, appealId);
			try (ResultSet result = pstatement.executeQuery();) {
				while (result.next()) {
					Student student = new Student();
					Evaluation evaluation = new Evaluation();
					StudentEvaluation studentEvaluation = new StudentEvaluation();
					studentEvaluation.setId(result.getInt("E.id"));
					studentEvaluation.setAppealId(result.getInt("E.idappeal"));
					
					student.setId(result.getInt("S.id"));
					student.setName(result.getString("S.name"));
					
					studentEvaluation.setStudent(student);
					studentEvaluation.setEvaluation(evaluation);
				}
			}
		}
		return evaluations;
	}

}
